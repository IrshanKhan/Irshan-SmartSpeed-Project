package actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Findelement1 {
	
	
	
	public WebElement findelement(WebDriver driver, String xpath) {
		
         
		
		return driver.findElement(By.xpath(xpath));
		
		
	}

}
