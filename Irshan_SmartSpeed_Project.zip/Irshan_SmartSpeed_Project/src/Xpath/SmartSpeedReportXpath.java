package Xpath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SmartSpeedReportXpath {
	
	public static WebDriver driver;
	public  SmartSpeedReportXpath(WebDriver driver){
		this.driver=driver;
	}
	
	
	
	public String SRN="//*[@Class='chosen-container chosen-container-single']";
	public String SRNsearch="//*[@Class='chosen-search-input']";
	public String GetDetails="//*[@mr-eye-widget-type='Button' and @mr-eye-widget-name='Get Details']";
	public String SRNClick="(//*[text()='47037, cherokee health park'])[2]";
	public String SRNClick1="(//*[text()='48009, mrt-praxis potsdam'])[2]";
	public String UncheckBrain="(//*[text()='Brain'])[1]";
	public String CheckKnee="(//*[text()='Knee'])[1]";
	public String Actual="//*[@mr-eye-widget-type='Button' and @mr-eye-widget-name='evaluation']";
	public String Aggressive="//*[@mr-eye-widget-type='Button' and @mr-eye-widget-name='acceleration']";
	public String Adoptiondownload="(//*[@mr-eye-widget-type='DownloadButton'])[4]";
	public String Examcount="(//*[@Class='sorting-arrow'])[2]";
	public String Examcard2="(//*[@Class='details-control'])[2]";
	public String SURVEY="(//*[@Class='markup-label'])[1]";
	public String Abdomen="(//*[text()='Abdomen'])[1]";
	public String Heart="(//*[text()='HEART'])[1]";
	
	public String Anatomicbutton="(//*[@Class='MuiSwitch-thumb css-jsexje-MuiSwitch-thumb'])[1]";
	public String Adoptionfullpackbutton="(//*[@Class='MuiSwitch-thumb css-jsexje-MuiSwitch-thumb'])[2]";
	
	public WebElement getElement(String xpath) {

		return driver.findElement(By.xpath(xpath));
	}

}
