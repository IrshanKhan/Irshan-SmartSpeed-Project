package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;



public class Base {
	
	public static WebDriver driver;
	
	
public void initializeBrowser(String Url) {
	
	
		
	String browserName = "chrome";
		if(browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.silentOutput","true");
			System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
			String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
			String foldername = "SmartSpeedReport";
			
			String Absolutefolderpath=System.getProperty("user.dir") + "\\Downloads\\"+foldername;
			//TO DO
			File f = new File(Absolutefolderpath);
			if(!f.exists()) {
				f.mkdirs();
				
			}
			String filename = "SmartSpeedReport";
			String destination = Absolutefolderpath+"\\" + filename + "_" + dateName + ".csv";
			
			  
			  Map<String, Object> prefsMap = new HashMap<String, Object>();
			  //prefsMap.put("profile.default_content_settings.popups", 0);
			  prefsMap.put("download.default_directory", Absolutefolderpath);
			  
			  ChromeOptions option = new ChromeOptions();
			  option.setExperimentalOption("prefs", prefsMap);
		     driver=new ChromeDriver(option);
		}else if(browserName.equalsIgnoreCase("firefox")) {
			
			//WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			
		}else if(browserName.equalsIgnoreCase("ie")) {
			
			//WebDriverManager.iedriver().setup();
			driver = new InternetExplorerDriver();
			
		}
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
		
		driver.get(Url);
		//driver.get("http://ingbtcpic5dtn96:5677/CT-Eye/bolusView/");
		
		

}

public WebDriver getdriver() {
	
	return driver;
	
}



}
