package com.CTEye.action;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.core.util.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.Select;







public class ActionMethod {

	public void scrollByVisibilityOfElement(WebDriver driver, WebElement ele) {
		
		boolean flag=false;
		flag=findElement(driver, ele);
		try {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", ele);
		flag=true;
		}
		catch(Exception e){
			
			System.out.println("Webelement not found");
		}
		
		
		// TODO Auto-generated method stub
		
	}

	public void click(WebDriver driver, WebElement ele) {
		
		
		   try {
			Actions act = new Actions(driver);
			act.moveToElement(ele).click().build().perform();
			
			
			}
			catch(Exception e){
				
				System.out.println("Webelement not found");
				
			}
		
		 
	}

	public boolean isDisplayed(WebDriver driver, WebElement ele) {
		boolean flag = false;
		flag = findElement(driver, ele);
		if (flag) {
			flag = ele.isDisplayed();
			if (flag) {
				System.out.println("The element is Displayed");
			} else {
				System.out.println("The element is not Displayed");
			}
		} else {
			System.out.println("Not displayed ");
		}
		return flag;
		// TODO Auto-generated method stub
		
	}

	public boolean type(WebElement ele, String text) {
		
		boolean flag = false;
		try {
			flag = ele.isDisplayed();
			ele.clear();
			ele.sendKeys(text);
			// logger.info("Entered text :"+text);
			flag = true;
		} catch (Exception e) {
			System.out.println("Location Not found");
			flag = false;
		} finally {
			if (flag) {
				System.out.println("Successfully entered value");
			} else {
				System.out.println("Unable to enter value");
			}

		}
		return flag;
		// TODO Auto-generated method stub
	
	}
	
	
	
	

	public boolean findElement(WebDriver ldriver, WebElement ele) {
		boolean flag = false;
		try {
			ele.isDisplayed();
			flag = true;
		} catch (Exception e) {
			System.out.println("Location not found: ");
			flag = false;
		} 
		finally {
			if (flag) {
				System.out.println("Successfully Found element at");

			} else {
				System.out.println("Unable to locate element at");
			}
		}
		return flag;
		// TODO Auto-generated method stub
	
	}

	public boolean isSelected(WebDriver driver, WebElement ele) {
		boolean flag = false;
		flag = findElement(driver, ele);
		if (flag) {
			flag = ele.isSelected();
			if (flag) {
				System.out.println("The element is Selected");
			} else {
				System.out.println("The element is not Selected");
			}
		} else {
			System.out.println("Not selected ");
		}
		return flag;
		// TODO Auto-generated method stub
		
	}

	public boolean isEnabled(WebDriver driver, WebElement ele) {
		boolean flag = false;
		flag = findElement(driver, ele);
		if (flag) {
			flag = ele.isEnabled();
			if (flag) {
				System.out.println("The element is Enabled");
			} else {
				System.out.println("The element is not Enabled");
			}
		} else {
			System.out.println("Not Enabled ");
		}
		return flag;
		// TODO Auto-generated method stub
		
	}

	public boolean selectBySendkeys(String value, WebElement ele) {
		boolean flag = false;
		try {
			
			ele.sendKeys(value);
			ele.sendKeys(Keys.ENTER);
			
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag) {
				System.out.println("Select value from the DropDown");		
			} else {
				System.out.println("Not Selected value from the DropDown");
				// throw new ElementNotFoundException("", "", "")
			}
		}
		// TODO Auto-generated method stub
	
	}
	
	public boolean selectBySendkeys1(String value, String value1, WebElement ele) {
		boolean flag = false;
		try {
			
			ele.sendKeys(value);
			ele.sendKeys(Keys.ENTER);
			ele.sendKeys(value1);
			ele.sendKeys(Keys.ENTER);
			
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag) {
				System.out.println("Select value from the DropDown");		
			} else {
				System.out.println("Not Selected value from the DropDown");
				// throw new ElementNotFoundException("", "", "")
			}
		}
		// TODO Auto-generated method stub
	
	}

	public boolean selectByIndex(WebElement element, int index) {
		
		boolean flag = false;
		try {
			Select s = new Select(element);
			s.selectByIndex(index);
			flag = true;
			return true;
		} catch (Exception e) {
			return false;
		} finally {
			if (flag) {
				System.out.println("Option selected by Index");
			} else {
				System.out.println("Option not selected by Index");
			}
		}
		// TODO Auto-generated method stub
	
	}

	public boolean selectByValue(WebElement element, String value) {
		
		boolean flag = false;
		try {
			Select s = new Select(element);
			s.selectByValue(value);
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag) {
				System.out.println("Option selected by Value");
			} else {
				System.out.println("Option not selected by Value");
			}
		}
		// TODO Auto-generated method stub
	}

	public boolean selectByVisibleText(String visibletext, WebElement ele) {
		boolean flag = false;
		try {
			Select s = new Select(ele);
			s.selectByVisibleText(visibletext);
			ele.click();
			
			flag = true;
			return true;
		} catch (Exception e) {
			return false;
		} finally {
			if (flag) {
				System.out.println("Option selected by VisibleText");
			} else {
				System.out.println("Option not selected by VisibleText");
			}
		}
		// TODO Auto-generated method stub
	
	}

	public boolean mouseHoverByJavaScript(WebDriver driver,WebElement ele) {
		boolean flag = false;
		try {
			WebElement mo = ele;
			String javaScript = "var evObj = document.createEvent('MouseEvents');"
					+ "evObj.initMouseEvent(\"mouseover\",true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);"
					+ "arguments[0].dispatchEvent(evObj);";
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(javaScript, mo);
			flag = true;
			return true;
		}

		catch (Exception e) {

			return false;
		} finally {
			if (flag) {
				System.out.println("MouseOver Action is performed");
			} else {
				System.out.println("MouseOver Action is not performed");
			}
		}
		// TODO Auto-generated method stub
		
	}

	public boolean JSClick(WebDriver driver, WebElement ele) {
		boolean flag = false;
		try {
			// WebElement element = driver.findElement(locator);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
			// driver.executeAsyncScript("arguments[0].click();", element);

			flag = true;

		}

		catch (Exception e) {
			throw e;

		} finally {
			if (flag) {
				System.out.println("Click Action is performed");
			} else if (!flag) {
				System.out.println("Click Action is not performed");
			}
		}
		return flag;
		// TODO Auto-generated method stub
		
	}

	public boolean switchToFrameByIndex(WebDriver driver, int index) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean switchToFrameById(WebDriver driver, String idValue) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean switchToFrameByName(WebDriver driver, String nameValue) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean switchToDefaultFrame(WebDriver driver) {
		// TODO Auto-generated method stub
		return false;
	}

	public void mouseOverElement(WebDriver driver, WebElement element) {
		boolean flag = false;
		try {
			new Actions(driver).moveToElement(element).build().perform();
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				System.out.println(" MouserOver Action is performed on ");
			} else {
				System.out.println("MouseOver action is not performed on");
			}
		}
		// TODO Auto-generated method stub
		
	}

	public boolean moveToElement(WebDriver driver, WebElement ele) {
		boolean flag = false;
		try {
			// WebElement element = driver.findElement(locator);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].scrollIntoView(true);", ele);
			Actions actions = new Actions(driver);
			// actions.moveToElement(driver.findElement(locator)).build().perform();
			actions.moveToElement(ele).click().build().perform();
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
		// TODO Auto-generated method stub
		
	}

	public boolean mouseover(WebDriver driver, WebElement ele) {
		boolean flag = false;
		try {
			new Actions(driver).moveToElement(ele).click().build().perform();
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				System.out.println(" MouserOver Action is performed on ");
			} else {
				System.out.println("MouseOver action is not performed on");
			}
		}
		// TODO Auto-generated method stub
		return false;
	}

	public boolean draggable(WebDriver driver, WebElement source, int x, int y) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean draganddrop(WebDriver driver, WebElement source, WebElement target) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean slider(WebDriver driver, WebElement ele, int x, int y) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean rightclick(WebDriver driver, WebElement ele) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean switchWindowByTitle(WebDriver driver, String windowTitle, int count) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean switchToNewWindow(WebDriver driver) {
		boolean flag = false;
		try {

			Set<String> s=driver.getWindowHandles();
			Object popup[]=s.toArray();
			driver.switchTo().window(popup[1].toString());
			flag = true;
			return flag;
		} catch (Exception e) {
			flag = false;
			return flag;
		} finally {
			if (flag) {
				System.out.println("Window is Navigated with title");				
			} else {
				System.out.println("The Window with title: is not Selected");
			}
		}
		// TODO Auto-generated method stub
		
	}

	public boolean switchToOldWindow(WebDriver driver) {
		boolean flag = false;
		try {

			Set<String> s=driver.getWindowHandles();
			Object popup[]=s.toArray();
			driver.switchTo().window(popup[0].toString());
			flag = true;
			return flag;
		} catch (Exception e) {
			flag = false;
			return flag;
		} finally {
			if (flag) {
				System.out.println("Focus navigated to the window with title");			
			} else {
				System.out.println("The Window with title: is not Selected");
			}
		}
		// TODO Auto-generated method stub
		
	}

	public int getColumncount(WebElement row) {
		List<WebElement> columns = row.findElements(By.tagName("td"));
		int a = columns.size();
		System.out.println(columns.size());
		for (WebElement column : columns) {
			System.out.print(column.getText());
			System.out.print("|");
		}
		return a;
		// TODO Auto-generated method stub
		
	}

	public int getRowCount(WebElement table) {
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		int a = rows.size() - 1;
		return a;
		// TODO Auto-generated method stub
	
	}

	public boolean Alert(WebDriver driver) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean launchUrl(WebDriver driver, String url) {
		boolean flag = false;
		try {
			driver.navigate().to(url);
			flag = true;
			return true;
		} catch (Exception e) {
			return false;
		} finally {
			if (flag) {
				System.out.println("Successfully launched \""+url+"\"");				
			} else {
				System.out.println("Failed to launch \""+url+"\"");
			}
		}
		// TODO Auto-generated method stub
	
	}

	public boolean isAlertPresent(WebDriver driver) {
		// TODO Auto-generated method stub
		return false;
	}

	public String getCurrentURL(WebDriver driver) {
		// TODO Auto-generated method stub
		return null;
	}

	public String getTitle(WebDriver driver) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean click1(WebElement locator, String locatorName) {
		boolean flag = false;
		try {
			locator.click();
			flag = true;
			return true;
		} catch (Exception e) {
			return false;
		} finally {
			if (flag) {
				System.out.println("Able to click on \""+locatorName+"\"");
			} else {
				System.out.println("Click Unable to click on \""+locatorName+"\"");
			}
		}
		// TODO Auto-generated method stub
		
	}

	public void fluentWait(WebDriver driver, WebElement element, int timeOut) {
		// TODO Auto-generated method stub
		
	}

	public void implicitWait(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		// TODO Auto-generated method stub
		
	}

	public void explicitWait(WebDriver driver, WebElement element, int timeOut) {
		// TODO Auto-generated method stub
		
	}

	public void pageLoadTimeOut(WebDriver driver) {
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		// TODO Auto-generated method stub
		
	}

	public String screenShot(WebDriver driver,String foldername, String filename) {
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
		File source = takesScreenshot.getScreenshotAs(OutputType.FILE);
		String Absolutefolderpath=System.getProperty("user.dir") + "\\ScreenShots\\"+foldername;
		//TO DO
		File f = new File(Absolutefolderpath);
		if(!f.exists()) {
			f.mkdirs();
			
		}
		String destination = Absolutefolderpath+"\\" + filename + "_" + dateName + ".png";
		
		
         
		try {
			FileHandler.copy(source, new File(destination));
		} catch (Exception e) {
			e.getMessage();
		}
		
		// This new path for jenkins
		String newImageString = "C:\\Users\\320198287\\eclipse-workspace\\Irshan_CTEye_Project\\Screenshots" + filename + "_"
				+ dateName + ".png";
		
		return newImageString;
		
		// TODO Auto-generated method stub
	
	}
	
	public static String capturescreenShot1(WebDriver driver) {
		//String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
		String base64Code=takesScreenshot.getScreenshotAs(OutputType.BASE64);
		return base64Code;
	}

	public String getCurrentTime() {
		// TODO Auto-generated method stub
		return null;
	}

	public void scrollByVisibilityOfElement1(WebDriver driver, WebElement ele) {
		// TODO Auto-generated method stub
		
	}

	public void doubleclick(WebDriver driver, WebElement ele) {
		
		Actions act = new Actions(driver);
		act.moveToElement(ele).doubleClick().build().perform();
		// TODO Auto-generated method stub
		
	}

	public void scrollToEnd(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight)");
		// TODO Auto-generated method stub
		
	}
	public void scrollToEnd1(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/0.8)");
		// TODO Auto-generated method stub
		
	}

	public void scrollToUp(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, -document.querySelector('.app-content').scrollHeight)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToHalf(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/6.4)");
		// TODO Auto-generated method stub
		
	}
	public void scrollToHalf1(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/4.7)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToHalfcs4(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/6)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToUp1(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, -document.querySelector('.app-content').scrollHeight/2)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToHalf2(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/1.8)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToHalf3(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/1.4)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToSysConfig(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/1.5)");
		// TODO Auto-generated method stub
		
	}
	public void scrollToHalf4(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/1.3)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToHalf01(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/2.6)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToSRN(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/2.4)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToHalf02(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/3)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToHalf03(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/2.2)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToHalf00(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/2)");
		// TODO Auto-generated method stub
		
	}
	public void scrollToHalf04(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/1.1)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToiw(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/11)");
		// TODO Auto-generated method stub
		
	}
	public void scrollToiw1(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/3.4)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToiw2(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/2.8)");
		// TODO Auto-generated method stub
		
	}
	public void scrollToiw3(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/1.9)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToiw4(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/1.6)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToiw5(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/1.2)");
		// TODO Auto-generated method stub
		
	}
	
	public void scrollToHalf05(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.app-content').scrollTo(0, document.querySelector('.app-content').scrollHeight/1.3)");
		// TODO Auto-generated method stub
		
	}
	
	
public String downloads(WebDriver driver,String foldername,String filename) throws InterruptedException {
		
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		String Absolutefolderpath=System.getProperty("user.dir") + "\\Downloads\\"+foldername;
		//TO DO
		File f = new File(Absolutefolderpath);
		if(!f.exists()) {
			f.mkdirs();
			
		}
		
		String destination = Absolutefolderpath+"\\" + filename + "_" + dateName + ".csv";
		
		  
		  Map<String, Object> prefsMap = new HashMap<String, Object>();
		  //prefsMap.put("profile.default_content_settings.popups", 0);
		  prefsMap.put("download.default_directory", Absolutefolderpath);
		  
		  ChromeOptions option = new ChromeOptions();
		  option.setExperimentalOption("prefs", prefsMap);
			return destination;

}

}
