package pages;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.CTEye.action.ActionMethod;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import Xpath.HomePageXpath;
import utility.Base;
import utility.Loading;


public class HomePage extends ActionMethod {
	
	
	static ExtentReports extentreport = new ExtentReports();

	static ExtentSparkReporter sparkreporter = new ExtentSparkReporter(
			"C:\\Users\\320198287\\eclipse-workspace\\Irshan_SmartSpeed_Project\\report.html");
	

	static Logger logger = Logger.getLogger("HomePage");

	
	HomePageXpath xpath;
	
	
	public static WebDriver driver;
	Loading l;

	@BeforeClass
	public void extentreport() throws IOException {
	
		extentreport.setSystemInfo("HostName", "MyHost");
		extentreport.setSystemInfo("ProjectName", "CTEye");
		extentreport.setSystemInfo("Tester", "Irshan");
		extentreport.setSystemInfo("OS", "Win10");
		extentreport.setSystemInfo("Browser", "Chrome");
		
	}

	@BeforeMethod

	public void setup() throws IOException, InterruptedException {

		Base b = new Base();
		logger.info("Webdriver initialization start");
		b.initializeBrowser("http://pww.mebef.healthcare.philips.com/Smart-Speed/"); 
		logger.info("Navigate to the end point URL");
		 
		driver = b.getdriver();
	    
		xpath = new HomePageXpath(driver);
		l=new Loading();
		
		
		extentreport.attachReporter(sparkreporter);
		
		l.loading(driver);
		//l.loading(driver);
        
        PropertyConfigurator.configure("Log4j.properties");

	}
	
	   @Test(priority = 1)

		public void Scenario_1() throws InterruptedException {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			ExtentTest test1 = extentreport.createTest("Scenario_1");

			Thread.sleep(2000);
			js.executeScript("window.scrollBy(0,-100)", "");
			logger.info("Taking screenshot of default KPIs");
			screenShot(driver, "scenario_1", "action_1");
			logger.info("Successfully Taken screenshot of default KPIs");
			test1.log(Status.PASS, "Take Screenshot");

			Thread.sleep(2000);
			logger.info("Clicking on reset in FilterPanel");
			click(driver, xpath.getElement(xpath.Resetbutton));
			logger.info("Successfully clicked");
			test1.log(Status.PASS, "Click on 'Reset' in 'FilterPanel");

			Thread.sleep(2000);
			l.loading(driver);

			Thread.sleep(2000);
			js.executeScript("window.scrollBy(0,-100)", "");

			Thread.sleep(2000);
			logger.info("Filtering by key-market ");
			click(driver, xpath.getElement(xpath.key_market));
			selectBySendkeys("IBERIA", xpath.getElement(xpath.key_market));
			logger.info("Successfully filtered");
			test1.log(Status.PASS, "Filter on 'Key-Market':['Iberia']");

			Thread.sleep(2000);
			logger.info("Filtering by SRN ");
			click(driver, xpath.getElement(xpath.SRN));
			Thread.sleep(2000);
			selectBySendkeys("32208", xpath.getElement(xpath.SRN));
			logger.info("Successfully filtered");
			test1.log(Status.PASS, "Filter on 'SRN':['32208']");

			Thread.sleep(2000);
			l.loading(driver);

			Thread.sleep(2000);
			js.executeScript("window.scrollBy(0,-100)", "");
			
			Thread.sleep(2000);
			logger.info("Taking screenshot of default KPIs");
			screenShot(driver, "scenario_1", "action_5");
			logger.info("Successfully Taken screenshot of default KPIs");
			test1.log(Status.PASS, "Take Screenshot");

			Thread.sleep(2000);
			logger.info("Clicking on reset in FilterPanel");
			click(driver, xpath.getElement(xpath.Resetbutton));
			logger.info("Successfully clicked");
			test1.log(Status.PASS, "Click on 'Reset' in 'FilterPanel");

			Thread.sleep(2000);
			l.loading(driver);

			Thread.sleep(2000);
			js.executeScript("window.scrollBy(0,-200)", "");
			logger.info("Filtering by Product-Type ");
			click(driver, xpath.getElement(xpath.Product_Type));
			selectBySendkeys("ACHIEVA 3.0T", xpath.getElement(xpath.Product_Type));
			click(driver, xpath.getElement(xpath.Product_Type));
			selectBySendkeys("MR 7700", xpath.getElement(xpath.Product_Type));
			logger.info("Successfully filtered");
			test1.log(Status.PASS, "Filter on 'Product':['ACHIEVA 3.0T','MR 7700']");

			Thread.sleep(2000);
			logger.info("Filtering by License_Type ");
			click(driver, xpath.getElement(xpath.License_Type));
			selectBySendkeys("None", xpath.getElement(xpath.License_Type));
			logger.info("Successfully filtered");
			test1.log(Status.PASS, "Filter on 'LicenseType':['NONE']");

			Thread.sleep(2000);
			l.loading(driver);

			Thread.sleep(2000);
			logger.info("Closing filterpanel ");
			click(driver, xpath.getElement(xpath.Filterbutton));
			logger.info("Closed filterpanel ");
			test1.log(Status.PASS, "Close FilterPanel");

			Thread.sleep(2000);
			logger.info("Taking screenshot of default KPIs");
			screenShot(driver, "scenario_1", "action_10");
			logger.info("Successfully Taken screenshot of default KPIs");
			test1.log(Status.PASS, "Take Screenshot");
			
			}
	 
	    @Test(priority = 2)

		public void Scenario_2() throws InterruptedException {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			ExtentTest test2 = extentreport.createTest("Scenario_2");

			logger.info("Scrolling to SRN Details");
			js.executeScript("window.scrollBy(0,500)", "");
			logger.info("Scrolled to SRN Details");
			test2.log(Status.PASS, "Scroll to 'SRN Details'");

			Thread.sleep(2000);
			logger.info("Taking screenshot of SRN Details");
			screenShot(driver, "scenario_2", "action_2");
			logger.info("Successfully Taken screenshot of SRN Details");
			test2.log(Status.PASS, "Take Screenshot");

			Thread.sleep(2000);
			logger.info("Downloading SRN Details");
			click(driver, xpath.getElement(xpath.SRNdowmloadbutton));
			logger.info("Downloaded");
			test2.log(Status.PASS, "Download as CSV in 'SRN Details'");

			Thread.sleep(2000);
			logger.info("Setting show entries to all");
			selectBySendkeys("All", xpath.getElement(xpath.SRNshowentries));
			logger.info("Successfully set");
			test2.log(Status.PASS, "Set 'Show Entries' to 'All' in 'SRN Details'");

			Thread.sleep(2000);
			logger.info(" Sorting hospital Name in  ascendig order in SRN Details ");
			click(driver, xpath.getElement(xpath.Hospitalname));
			logger.info(" Successfully sorted ");
			test2.log(Status.PASS, "Sort on 'Hospital Name' ascendingly in 'SRN Details'");

			Thread.sleep(2000);
			logger.info("Searching 47342 in SRN Details");
			type(xpath.getElement(xpath.SRNsearch), "47342");
			logger.info("Successfully search");
			test2.log(Status.PASS, "Enter 'Search' = '47342' in 'SRN Details'");

			Thread.sleep(2000);
			logger.info("Taking screenshot of SRN Details");
			screenShot(driver, "scenario_2", "action_7");
			logger.info("Successfully Taken screenshot of SRN Details");
			test2.log(Status.PASS, "Take Screenshot");

			Thread.sleep(2000);
			logger.info("Scrolling to Up");
			js.executeScript("window.scrollBy(0,-600)", "");
			logger.info("Scrolled to Up");
			test2.log(Status.PASS, "Scroll to up");

			Thread.sleep(2000);
			logger.info("Filtering by key-market ");
			click(driver, xpath.getElement(xpath.key_market));
			selectBySendkeys("DACH (GERMANY, AUSTRIA, SWITZERLAND)", xpath.getElement(xpath.key_market));
			logger.info("Successfully filtered");
			test2.log(Status.PASS, "Filter on 'Key-Market':['DACH']");

			Thread.sleep(2000);
			logger.info("Filtering by SRN ");
			click(driver, xpath.getElement(xpath.SRN));
			selectBySendkeys("45552", xpath.getElement(xpath.SRN));
			logger.info("Successfully filtered");
			test2.log(Status.PASS, "Filter on 'SRN':['45552']");

			Thread.sleep(2000);
			l.loading(driver);

			Thread.sleep(2000);
			logger.info("Scrolling to SRN Details");
			js.executeScript("window.scrollBy(0,500)", "");
			logger.info("Scrolled to SRN Details");
			test2.log(Status.PASS, "Scroll to 'SRN Details'");
			
			Thread.sleep(2000);
			logger.info("Taking screenshot of SRN Details");
			screenShot(driver, "scenario_2", "action_12");
			logger.info("Successfully Taken screenshot of SRN Details");
			test2.log(Status.PASS, "Take Screenshot");

			Thread.sleep(10000);
			logger.info("Downloading SRN Details");
			click(driver, xpath.getElement(xpath.SRNdowmloadbutton));
			logger.info("Downloaded");
			test2.log(Status.PASS, "Download as CSV in 'SRN Details'");
			
	 }
	 
	   @Test(priority = 3)

		public void Scenario_3() throws InterruptedException {
		    JavascriptExecutor js = (JavascriptExecutor) driver;
			ExtentTest test3 = extentreport.createTest("Scenario_3");
			
			logger.info("Scrolling to Adoption Trend");
			js.executeScript("window.scrollBy(0,900)", "");
			logger.info("Scrolled to Adoption Trend");
			test3.log(Status.PASS, "Scroll to 'Adoption Trend'");
			
			Thread.sleep(2000);
			logger.info("Taking screenshot of Adoption Trend");
			screenShot(driver, "scenario_3", "action_2");
			logger.info("Successfully Taken screenshot of Adoption Trend");
			test3.log(Status.PASS, "Take Screenshot");
			
			Thread.sleep(2000);
			logger.info("Downloading Adoption trend");
			click(driver, xpath.getElement(xpath.Adoptiontrenddowmloadbutton));
			logger.info("Downloaded");
			test3.log(Status.PASS, "Download as CSV in 'Adoption Trend'");
			
			Thread.sleep(2000);
			logger.info("Clicking on InstalledLicense ");
			click(driver, xpath.getElement(xpath.InstalledLicense));
			logger.info("Successfully clicked");
			test3.log(Status.PASS, "Click on 'InstalledLicense' in 'Adoption Trend'");
			
			Thread.sleep(2000);
			logger.info("Downloading Adoption trend");
			click(driver, xpath.getElement(xpath.Adoptiontrenddowmloadbutton));
			logger.info("Downloaded");
			test3.log(Status.PASS, "Download as CSV in 'Adoption Trend'");
			
			Thread.sleep(2000);
			logger.info("Scrolling to UP");
			js.executeScript("window.scrollBy(0,-1200)", "");
			logger.info("Successfully scrolled");
			test3.log(Status.PASS, "Scroll to up");
			
			Thread.sleep(2000);
			logger.info("Filtering by Countries ");
			click(driver, xpath.getElement(xpath.Countries));
			selectBySendkeys("ARGENTINA",xpath.getElement(xpath.Countries));
			logger.info("Successfully filtered");
			test3.log(Status.PASS, "Filter on 'Countries':['ARGENTINA']");
			
			Thread.sleep(2000);
			l.loading(driver);
			
			Thread.sleep(2000);
			logger.info("Scrolling to Adoption Trend");
			js.executeScript("window.scrollBy(0,900)", "");
			logger.info("Scrolled to Adoption Trend");
			test3.log(Status.PASS, "Scroll to 'Adoption Trend'");
			
			Thread.sleep(2000);
			logger.info("Clicking on Showcommercial ");
			click(driver, xpath.getElement(xpath.Showcommercial));
			logger.info("Successfully clicked");
			test3.log(Status.PASS, "Click on 'Showcommercial' in 'Adoption Trend'");
			
			
			Thread.sleep(2000);
			logger.info("Taking screenshot of 'Adoption trend");
			screenShot(driver, "scenario_3", "action_10");
			logger.info("Successfully Taken screenshot of 'Adoption trend");
			test3.log(Status.PASS, "Take Screenshot");
			
			Thread.sleep(2000);
			logger.info("Scrolling to UP");
			js.executeScript("window.scrollBy(0,-1200)", "");
			logger.info("Successfully scrolled");
			test3.log(Status.PASS, "Scroll to up");
			
			Thread.sleep(2000);
			logger.info("Clicking on reset in FilterPanel");
			click(driver, xpath.getElement(xpath.Resetbutton));
			logger.info("Successfully clicked");
			test3.log(Status.PASS, "Click on 'Reset' in 'FilterPanel");
			
			Thread.sleep(2000);
			l.loading(driver);
			
			Thread.sleep(2000);
			logger.info("Scrolling to Adoption Trend");
			js.executeScript("window.scrollBy(0,1100)", "");
			logger.info("Scrolled to Adoption Trend");
			test3.log(Status.PASS, "Scroll to 'Adoption Trend'");
			
			
			Thread.sleep(2000);
			logger.info("Clicking on Showcommercial ");
			click(driver, xpath.getElement(xpath.Showcommercial));
			logger.info("Successfully clicked");
			test3.log(Status.PASS, "Click on 'Showcommercial' in 'Adoption Trend'");
			
			Thread.sleep(2000);
			logger.info("Taking screenshot of Adoption Trend");
			screenShot(driver, "scenario_3", "action_15");
			logger.info("Successfully Taken screenshot of Adoption Trend");
			test3.log(Status.PASS, "Take Screenshot");
			
			
			Thread.sleep(2000);
			logger.info("Downloading Adoption Trend");
			click(driver, xpath.getElement(xpath.Adoptiontrenddowmloadbutton));
			logger.info("Downloaded");
			test3.log(Status.PASS, "Download as CSV in 'Adoption Trend'");
			
			}
			
			
	 @Test(priority = 4)

		public void Scenario_4() throws InterruptedException {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			ExtentTest test4 = extentreport.createTest("Scenario_4");

			logger.info("Scrolling to Adoption Inception");
			js.executeScript("window.scrollBy(0,1400)", "");
			logger.info("Scrolled to Adoption Inception");
			test4.log(Status.PASS, "Scroll to 'Adoption Inception'");

			Thread.sleep(2000);
			logger.info("Clicking on Adoptionsincebutton ");
			click(driver, xpath.getElement(xpath.Adoptionsince));
			logger.info("Successfully clicked");
			test4.log(Status.PASS, "Click on 'AdoptionLicense' in 'Adoption Inception'");

			Thread.sleep(2000);
			logger.info("Taking screenshot of Adoption Inception");
			screenShot(driver, "scenario_4", "action_3");
			logger.info("Successfully Taken screenshot of Adoption Inception");
			test4.log(Status.PASS, "Take Screenshot");

			Thread.sleep(2000);
			logger.info("Scrolling to UP");
			js.executeScript("window.scrollBy(0,-1600)", "");
			logger.info("Successfully scrolled");
			test4.log(Status.PASS, "Scroll to up");

			Thread.sleep(2000);
			logger.info("Clicking on reset in FilterPanel");
			click(driver, xpath.getElement(xpath.Resetbutton));
			logger.info("Successfully clicked");
			test4.log(Status.PASS, "Click on 'Reset' in 'FilterPanel");

			Thread.sleep(2000);
			l.loading(driver);

			Thread.sleep(2000);
			logger.info("Filtering by License_Type ");
			click(driver, xpath.getElement(xpath.License_Type));
			selectBySendkeys("Commercial", xpath.getElement(xpath.License_Type));
			logger.info("Successfully filtered");
			test4.log(Status.PASS, "Filter on 'License_Type':['Commercial']");
			
			Thread.sleep(2000);
			l.loading(driver);

			Thread.sleep(2000);
			logger.info("Scrolling to Adoption Inception");
			js.executeScript("window.scrollBy(0,1500)", "");
			logger.info("Scrolled to Adoption Inception");
			test4.log(Status.PASS, "Scroll to 'Adoption Inception'");

			Thread.sleep(2000);
			logger.info("Taking screenshot of 'Adoption trend");
			screenShot(driver, "scenario_4", "action_8");
			logger.info("Successfully Taken screenshot of 'Adoption trend");
			test4.log(Status.PASS, "Take Screenshot");

			Thread.sleep(2000);
			logger.info("Clicking on Adoptionsincebutton ");
			click(driver, xpath.getElement(xpath.Adoptionsince));
			logger.info("Successfully clicked");
			test4.log(Status.PASS, "Click on 'Adoptionsinceinception' in 'Adoption Trend Since Inception'");
			
			Thread.sleep(2000);
			logger.info("Taking screenshot of 'Adoption trend");
			screenShot(driver, "scenario_4", "action_10");
			logger.info("Successfully Taken screenshot of 'Adoption trend");
			test4.log(Status.PASS, "Take Screenshot");

			Thread.sleep(2000);
			logger.info("Downloading Adoption Trend");
			click(driver, xpath.getElement(xpath.Adoptionsincedownloadbutton));
			logger.info("Downloaded");
			test4.log(Status.PASS, "Download as CSV in 'Adoption Trend Since Inception'");
				
				
			
	 }
	 
	 
	   @Test(priority = 5)

		public void Scenario_5() throws InterruptedException {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			ExtentTest test5 = extentreport.createTest("Scenario_5");

			logger.info("Scrolling to Adoption Per Anatomy");
			js.executeScript("window.scrollBy(0,1900)", "");
			logger.info("Scrolled to Adoption Per Anatomy");
			test5.log(Status.PASS, "Scroll to 'Adoption Per Anatomy'");

			Thread.sleep(2000);
			logger.info("Clicking on enabledexam");
			click(driver, xpath.getElement(xpath.enabledexam));
			logger.info("Successfully clciked");
			test5.log(Status.PASS, "Click on 'Smart Speed enabled Exam %' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Taking screenshot of Per Anatomy");
			screenShot(driver, "scenario_5", "action_3");
			logger.info("Successfully Taken screenshot of Per Anatomy");
			test5.log(Status.PASS, "Take Screenshot");

			Thread.sleep(2000);
			logger.info("Downloading Adoption Per Anatomy");
			click(driver, xpath.getElement(xpath.Anatomydownload));
			logger.info("Downloaded");
			test5.log(Status.PASS, "Download as CSV in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Setting show entries to 50");
			selectBySendkeys("50", xpath.getElement(xpath.Anatomyshowentries));
			logger.info("Successfully set");
			test5.log(Status.PASS, "Set 'Show Entries' to '50' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info(" Sorting Totalscan in  ascendig order in Adoption Per Anatomy ");
			click(driver, xpath.getElement(xpath.Totalscan));
			logger.info(" Successfully sorted ");
			test5.log(Status.PASS, "Sort on 'Totalscan' ascendingly in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Taking screenshot of Per Anatomy");
			screenShot(driver, "scenario_5", "action_7");
			logger.info("Successfully Taken screenshot of Per Anatomy");
			test5.log(Status.PASS, "Take Screenshot");

			Thread.sleep(2000);
			logger.info("Clicking on Scanlevel");
			click(driver, xpath.getElement(xpath.Scanlevel));
			logger.info("Successfully clciked");
			test5.log(Status.PASS, "Click on 'Scanlevel' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Setting view by to Anatomicregion");
			click(driver, xpath.getElement(xpath.Anatomyviewby));
			click(driver, xpath.getElement(xpath.Anatomicregion));
			logger.info("Successfully set");
			test5.log(Status.PASS, "Set 'View By' to 'AnatomicRegion' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Searching 102 in SRN Details");
			type(xpath.getElement(xpath.Anatomysearch), "102");
			logger.info("Successfully search");
			test5.log(Status.PASS, "Enter 'Search' = '102' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Downloading SRN Details");
			click(driver, xpath.getElement(xpath.Anatomydownload));
			logger.info("Downloaded");
			test5.log(Status.PASS, "Download as CSV in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Taking screenshot of Per Anatomy");
			screenShot(driver, "scenario_5", "action_12");
			logger.info("Successfully Taken screenshot of Per Anatomy");
			test5.log(Status.PASS, "Take Screenshot");
			

		 }
	   @Test(priority = 6)

		public void Scenario_6() throws InterruptedException {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			ExtentTest test6 = extentreport.createTest("Scenario_6");

			logger.info("Scrolling to Adoption Per Anatomy");
			js.executeScript("window.scrollBy(0,1900)", "");
			logger.info("Scrolled to Adoption Per Anatomy");
			test6.log(Status.PASS, "Scroll to 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Setting show entries to All");
			selectBySendkeys("All", xpath.getElement(xpath.Anatomyshowentries));
			logger.info("Successfully set");
			test6.log(Status.PASS, "Set 'Show Entries' to 'All' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Clicking on Scanlevel");
			click(driver, xpath.getElement(xpath.Scanlevel));
			logger.info("Successfully clciked");
			test6.log(Status.PASS, "Click on 'Scanlevel' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info(" Sorting Totalscan in  ascendig order inAdoption Per Anatomy ");
			click(driver, xpath.getElement(xpath.Totalscan));
			logger.info(" Successfully sorted ");
			test6.log(Status.PASS, "Sort on 'Totalscan' ascendingly in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Taking screenshot of Per Anatomy");
			screenShot(driver, "scenario_6", "action_5");
			logger.info("Successfully Taken screenshot of Per Anatomy");
			test6.log(Status.PASS, "Take Screenshot");

			Thread.sleep(2000);
			logger.info("Scrolling to UP");
			js.executeScript("window.scrollBy(0,-2100)", "");
			logger.info("Successfully scrolled");
			test6.log(Status.PASS, "Scroll to up");

			Thread.sleep(2000);
			logger.info("Filtering by Countries ");
			click(driver, xpath.getElement(xpath.Countries));
			selectBySendkeys("JAPAN",xpath.getElement(xpath.Countries));
			logger.info("Successfully filtered");
			test6.log(Status.PASS, "Filter on 'Countries':['JAPAN']");

			Thread.sleep(2000);
			logger.info("Filtering by SRN ");
			click(driver, xpath.getElement(xpath.SRN));
			selectBySendkeys("84118", xpath.getElement(xpath.SRN));
			logger.info("Successfully filtered");
			test6.log(Status.PASS, "Filter on 'SRN':['84118']");
			
			Thread.sleep(2000);
			l.loading(driver);

			logger.info("Scrolling to Adoption Per Anatomy");
			js.executeScript("window.scrollBy(0,1800)", "");
			logger.info("Scrolled to Adoption Per Anatomy");
			test6.log(Status.PASS, "Scroll to 'Adoption Per Anatomy'");
			
			Thread.sleep(2000);
			logger.info("Setting view by to Anatomicregion");
			click(driver, xpath.getElement(xpath.Anatomyviewby));
			click(driver, xpath.getElement(xpath.Anatomicregion));
			logger.info("Successfully set");
			test6.log(Status.PASS, "Set 'View By' to 'AnatomicRegion' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Searching CERVICAL SPINE in SRN Details");
			type(xpath.getElement(xpath.Anatomysearch), "CERVICAL SPINE");
			logger.info("Successfully search");
			test6.log(Status.PASS, "Enter 'Search' = 'CERVICAL SPINE' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Downloading SRN Details");
			click(driver, xpath.getElement(xpath.Anatomydownload1));
			logger.info("Downloaded");
			test6.log(Status.PASS, "Download as CSV in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Taking screenshot of Per Anatomy");
			screenShot(driver, "scenario_6", "action_13");
			logger.info("Successfully Taken screenshot of Per Anatomy");
			test6.log(Status.PASS, "Take Screenshot");
			
			}
			
		@Test(priority = 7)

		public void Scenario_7() throws InterruptedException {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			ExtentTest test7 = extentreport.createTest("Scenario_7");

			logger.info("Scrolling to Adoption Per Anatomy");
			js.executeScript("window.scrollBy(0,1900)", "");
			logger.info("Scrolled to Adoption Per Anatomy");
			test7.log(Status.PASS, "Scroll to 'Adoption Per Anatomy'");

			Thread.sleep(2000);
			logger.info("Clicking on Adoptionperscantype");
			click(driver, xpath.getElement(xpath.Adoptionperscantype));
			logger.info("Clicking on Scanlevel");
			test7.log(Status.PASS, "Click on 'Adoption Per Scan Type' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			l.loading1(driver);

			Thread.sleep(2000);
			js.executeScript("window.scrollBy(0,300)", "");
			
			Thread.sleep(2000);
			logger.info("Searching 14.57% in AdoptionTabsDetails");
			type(xpath.getElement(xpath.Anatomysearch), "14.57%");
			logger.info("Successfully search");
			test7.log(Status.PASS, "Enter 'Search' = '14.57%' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Taking screenshot of Per Anatomy");
			screenShot(driver, "scenario_7", "action_4");
			logger.info("Successfully Taken screenshot of Per Anatomy");
			test7.log(Status.PASS, "Take Screenshot");

			Thread.sleep(2000);
			logger.info("Scrolling to UP");
			js.executeScript("window.scrollBy(0,-2100)", "");
			logger.info("Successfully scrolled");
			test7.log(Status.PASS, "Scroll to up");

			Thread.sleep(2000);
			logger.info("Filtering by key-market ");
			click(driver, xpath.getElement(xpath.key_market));
			selectBySendkeys("DACH (GERMANY, AUSTRIA, SWITZERLAND)", xpath.getElement(xpath.key_market));
			click(driver, xpath.getElement(xpath.key_market));
			selectBySendkeys("GREATER CHINA", xpath.getElement(xpath.key_market));
			logger.info("Successfully filtered");
			test7.log(Status.PASS, "Filter on 'Key-Market':['DACH (GERMANY, AUSTRIA, SWITZERLAND)','GREATER CHINA']");

			Thread.sleep(2000);
			logger.info("Filtering by SRN ");
			click(driver, xpath.getElement(xpath.SRN));
			selectBySendkeys("47301", xpath.getElement(xpath.SRN));
			click(driver, xpath.getElement(xpath.SRN));
			selectBySendkeys("45552", xpath.getElement(xpath.SRN));
			logger.info("Successfully filtered");
			test7.log(Status.PASS, "Filter on 'SRN':['47301','45552']");
			
			Thread.sleep(2000);
			l.loading(driver);

			logger.info("Scrolling to Adoption Per Anatomy");
			js.executeScript("window.scrollBy(0,1900)", "");
			logger.info("Scrolled to Adoption Per Anatomy");
			test7.log(Status.PASS, "Scroll to 'Adoption Per Anatomy'");

			Thread.sleep(2000);
			logger.info("Clicking on Scanlevel");
			click(driver, xpath.getElement(xpath.Scanlevel));
			logger.info("Successfully clciked");
			test7.log(Status.PASS, "Click on 'Scanlevel' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Clicking on notenabledexam");
			click(driver, xpath.getElement(xpath.notenabledexam));
			logger.info("Successfully clciked");
			test7.log(Status.PASS, "Click on 'Not enabled Exams' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Setting view by to Anatomyperimagingseq");
			click(driver, xpath.getElement(xpath.Anatomyviewby));
			click(driver, xpath.getElement(xpath.Anatomyperimagingseq));
			logger.info("Successfully set");
			test7.log(Status.PASS, "Set 'View By' to 'Anatomy Per Imaging Sequence' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Setting show entries to All");
			selectBySendkeys("All", xpath.getElement(xpath.Anatomyshowentries));
			logger.info("Successfully set");
			test7.log(Status.PASS, "Set 'Show Entries' to 'All' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info(" Sorting Totalscan in  ascendig order in Per Anatomy ");
			doubleclick(driver, xpath.getElement(xpath.ImagingMode));
			logger.info(" Successfully sorted ");
			test7.log(Status.PASS, "Sort on 'Totalscan' ascendingly in 'AdoptionTabsDetails'");
			
			Thread.sleep(2000);
			logger.info("Downloading AdoptionTabsDetails");
			click(driver, xpath.getElement(xpath.Anatomydownload1));
			logger.info("Downloaded");
			test7.log(Status.PASS, "Download as CSV in 'AdoptionTabsDetails'");


			
			 }
	 
	 @Test(priority = 8)

		public void Scenario_8() throws InterruptedException {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			ExtentTest test8 = extentreport.createTest("Scenario_8");

			logger.info("Scrolling to Adoption Per Anatomy");
			js.executeScript("window.scrollBy(0,1900)", "");
			logger.info("Scrolled to Adoption Per Anatomy");
			test8.log(Status.PASS, "Scroll to 'Adoption Per Anatomy'");

			Thread.sleep(2000);
			logger.info("Clicking on Adoptionpersystemtype");
			click(driver, xpath.getElement(xpath.Adoptionpersystemtype));
			logger.info("Clicking on Scanlevel");
			test8.log(Status.PASS, "Click on 'Adoption Per System Type' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			l.loading1(driver);

			Thread.sleep(2000);
			js.executeScript("window.scrollBy(0,300)", "");

			Thread.sleep(2000);
			logger.info("Clicking on Scanlevel");
			click(driver, xpath.getElement(xpath.Scanlevel));
			logger.info("Successfully clciked");
			test8.log(Status.PASS, "Click on 'Scanlevel' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Setting view by to anatomyperstrength");
			click(driver, xpath.getElement(xpath.Anatomyviewby));
			click(driver, xpath.getElement(xpath.anatomyperstrength));
			logger.info("Successfully set");
			test8.log(Status.PASS, "Set 'View By' to 'Anatomy Per Field Strength' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Taking screenshot of Per Anatomy");
			screenShot(driver, "scenario_8", "action_5");
			logger.info("Successfully Taken screenshot of Per Anatomy");
			test8.log(Status.PASS, "Take Screenshot");

			Thread.sleep(2000);
			logger.info("Scrolling to UP");
			js.executeScript("window.scrollBy(0,-2100)", "");
			logger.info("Successfully scrolled");
			test8.log(Status.PASS, "Scroll to up");

			Thread.sleep(2000);
			logger.info("Clicking on reset in FilterPanel");
			click(driver, xpath.getElement(xpath.Resetbutton));
			logger.info("Successfully clicked");
			test8.log(Status.PASS, "Click on 'Reset' in 'FilterPanel");

			Thread.sleep(2000);
			l.loading(driver);

			logger.info("Scrolling to UP");
			js.executeScript("window.scrollBy(0,-100)", "");
			logger.info("Successfully scrolled");
			test8.log(Status.PASS, "Scroll to up");

			Thread.sleep(2000);
			logger.info("Filtering by Product_Type ");
			click(driver, xpath.getElement(xpath.Product_Type));
			selectBySendkeys("INGENIA 3.0T (DDAS)", xpath.getElement(xpath.Product_Type));
			click(driver, xpath.getElement(xpath.Product_Type));
			selectBySendkeys("ACHIEVA 1.5T", xpath.getElement(xpath.Product_Type));
			click(driver, xpath.getElement(xpath.Product_Type));
			selectBySendkeys("PANORAMA 1.0T", xpath.getElement(xpath.Product_Type));
			logger.info("Successfully filtered");
			test8.log(Status.PASS, "Filter on 'Product':['INGENIA 3.0T (DDAS)','ACHIEVA 1.5T','PANORAMA 1.0T']");

			Thread.sleep(2000);
			logger.info("Filtering by SRN ");
			click(driver, xpath.getElement(xpath.Countries));
			selectBySendkeys("JAPAN", xpath.getElement(xpath.Countries));
			logger.info("Successfully filtered");
			test8.log(Status.PASS, "Filter on 'SRN':['JAPAN']");

			Thread.sleep(2000);
			logger.info("Closing filterpanel ");
			click(driver, xpath.getElement(xpath.Filterbutton));
			logger.info("Closed filterpanel ");
			test8.log(Status.PASS, "Close FilterPanel");

			Thread.sleep(2000);
			l.loading(driver);

			logger.info("Scrolling to Adoption Per Anatomy");
			js.executeScript("window.scrollBy(0,1900)", "");
			logger.info("Scrolled to Adoption Per Anatomy");
			test8.log(Status.PASS, "Scroll to 'Adoption Per Anatomy'");

			Thread.sleep(2000);
			logger.info("Searching INGENIA 3.0T (DDAS) in SRN Details");
			type(xpath.getElement(xpath.Anatomysearch), "INGENIA 3.0T (DDAS)");
			logger.info("Successfully search");
			test8.log(Status.PASS, "Enter 'Search' = 'INGENIA 3.0T (DDAS)' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info("Setting show entries to 25");
			selectBySendkeys("25", xpath.getElement(xpath.Anatomyshowentries));
			logger.info("Successfully set");
			test8.log(Status.PASS, "Set 'Show Entries' to '25' in 'AdoptionTabsDetails'");

			Thread.sleep(2000);
			logger.info(" Sorting Totalscan in  ascendig order in Per Anatomy ");
			doubleclick(driver, xpath.getElement(xpath.ImagingMode));
			logger.info(" Successfully sorted ");
			test8.log(Status.PASS, "Sort on 'ImagingMode' ascendingly in 'AdoptionTabsDetails'");
			
			Thread.sleep(2000);
			logger.info("Taking screenshot of Per Anatomy");
			screenShot(driver, "scenario_8", "action_16");
			logger.info("Successfully Taken screenshot of Per Anatomy");
			test8.log(Status.PASS, "Take Screenshot");

			Thread.sleep(2000);
			logger.info("Downloading SRN Details");
			click(driver, xpath.getElement(xpath.Anatomydownload1));
			logger.info("Downloaded");
			test8.log(Status.PASS, "Download as CSV in 'AdoptionTabsDetails'");
			
			
	
	 }
	 @AfterMethod()

		public void teardown() {

			extentreport.flush();
			
			//driver.quit();

		}

}
