package Xpath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SRNPageXpath {
	
	public static WebDriver driver;
	public  SRNPageXpath(WebDriver driver){
		this.driver=driver;
	}
	
	
	
	public String Beforeuseshowentries="//*[@mr-eye-widget-type='DropDown' and @mr-eye-widget-name='Show Entries']";
	public String Beforeusesearch="//*[@mr-eye-widget-type='TextField' and @mr-eye-widget-name='Search']";
	public String Beforescandownload="(//*[@mr-eye-widget-type='DownloadButton'])[1]";
	public String Afteruseshowentries="(//*[@mr-eye-widget-type='DropDown' and @mr-eye-widget-name='Show Entries'])[2]";
	public String Afterusesearch="(//*[@mr-eye-widget-type='TextField' and @mr-eye-widget-name='Search'])[2]";
	public String Afterscandownload="(//*[@mr-eye-widget-type='DownloadButton'])[4]";
	public String Beforeactivitydownload="(//*[@mr-eye-widget-type='DownloadButton'])[2]";
	public String Afteractivitydownload="(//*[@mr-eye-widget-type='DownloadButton'])[5]";
	public String Anatomymixdownload="(//*[@mr-eye-widget-type='DownloadButton'])[3]";
	public String Adoptionanatomydownload="(//*[@mr-eye-widget-type='DownloadButton'])[6]";
	public String Adoptiondownload="(//*[@mr-eye-widget-type='DownloadButton'])[7]";
	public String Examcount="(//*[@Class='sorting-arrow'])[2]";
	public String sscount="(//*[@Class='sorting-arrow'])[10]";
	public String Examcard2="(//*[@Class='details-control'])[2]";
	public String Examcard14="(//*[@Class='details-control'])[14]";
	public String SURVEY="(//*[@Class='markup-label'])[1]";
	public String Abdomen="(//*[text()='Abdomen'])[1]";
	public String Spine="(//*[text()='Spine'])[1]";
	public String Knee="(//*[text()='95'])[2]";
	public String Brain="(//*[text()='107'])[2]";
	
	
	public String Anatomicbutton="//*[@mr-eye-widget-type='Button' and @mr-eye-widget-name='AnatomyRegion']";
	public String Adoptionperanatomybutton="//*[@mr-eye-widget-type='Button' and @mr-eye-widget-name='AdoptionLicensePerSRN']";
	public String Adoptionfullpackbutton="//*[@mr-eye-widget-type='Button' and @mr-eye-widget-name='AdoptionSwitch']";
	
	public WebElement getElement(String xpath) {

		return driver.findElement(By.xpath(xpath));
	}
}
