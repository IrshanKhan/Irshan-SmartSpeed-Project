package Xpath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePageXpath {
	
	public static WebDriver driver;
	public  HomePageXpath(WebDriver driver){
		this.driver=driver;
	}
	
	//public String GPU ="(//*[@mr-eye-widget-type='Table' and @mr-eye-widget-name='SRN List'])[1]//descendant::table//tbody//tr[8]";
	
	public String adoptioninception="//*[@mr-eye-widget-type='Chart' and @mr-eye-widget-name='Adoption Trend since Inception']]//descendant::*[@mr-eye-widget-name='Show Entries']";
	
	public String key_market="(//*[@type='text'])[1]";
	public String Product_Type  ="(//*[@type='text'])[2]";
	public String SRN="(//*[@type='text'])[3]";
	public String Countries="(//*[@type='text'])[4]";
	public String Regions="(//*[@type='text'])[5]";
	public String License_Type="(//*[@type='text'])[6]";
	public String Closebutton="//*[@mr-eye-widget-type='Button' and @mr-eye-widget-name='Close Button']";
	public String Resetbutton="//*[@mr-eye-widget-type='Button' and @mr-eye-widget-name='Reset']";
	public String Filterbutton="//*[@mr-eye-widget-type='Button' and @mr-eye-widget-name='Filter']";
	
	
	public String SRNshowentries="(//*[@mr-eye-widget-type='DropDown' and @mr-eye-widget-name='Show Entries'])[1]";
	public String SRNsearch="(//*[@mr-eye-widget-type='TextField' and @mr-eye-widget-name='Search'])[1]";
	public String SRNdowmloadbutton="(//*[@mr-eye-widget-type='DownloadButton'])[1]";
	public String Hospitalname="(//*[@Class='sorting-arrow'])[2]";
	public String Compatibility="(//*[@Class='sorting-arrow'])[8]";
	public String Licensestate="(//*[@Class='sorting-arrow'])[5]";
	
	public String Showcommercial="//*[@mr-eye-widget-type='Button' and @mr-eye-widget-name='AdoptionCommercial']";
	public String InstalledLicense="//*[@mr-eye-widget-type='Button' and @mr-eye-widget-name='AdoptionLicense']";
	public String Adoptionsince="//*[@mr-eye-widget-type='Button' and @mr-eye-widget-name='AdoptionInceptionSwitch']";
	public String Adoptiontrenddowmloadbutton="(//*[@mr-eye-widget-type='DownloadButton'])[2]";
	public String Adoptionsincedownloadbutton="(//*[@mr-eye-widget-type='DownloadButton'])[3]";
	
	public String Anatomyshowentries="(//*[@mr-eye-widget-type='DropDown' and @mr-eye-widget-name='Show Entries'])[2]";
	public String Anatomysearch="(//*[@mr-eye-widget-type='TextField' and @mr-eye-widget-name='Search'])[2]";
	public String Anatomyviewby="//*[@mr-eye-widget-type='DropDown' and @mr-eye-widget-name='View By']";
	public String Scanlevel="//*[@mr-eye-widget-type='Button' and @mr-eye-widget-name='ScanLevel']";
	public String Anatomicregion="(//*[text()='Anatomic Region'])[1]";
	public String Anatomyperimaging="//*[text()='Anatomy Per Imaging']";
	public String Anatomyperimagingseq="//*[text()='Anatomy Per Imaging Sequence']";
	public String Adoptionsincebutton="(//*[@Class='MuiSwitch-thumb css-jsexje-MuiSwitch-thumb'])[3]";
	public String Adoptionsincebutton1="(//*[@Class='MuiSwitch-thumb css-jsexje-MuiSwitch-thumb'])[1]";
	public String Anatomyexamlevel="(//*[@Class='MuiSwitch-thumb css-jsexje-MuiSwitch-thumb'])[4]";
	public String Anatomydownload="(//*[@mr-eye-widget-type='DownloadButton'])[4]";
	public String Anatomydownload1="(//*[@mr-eye-widget-type='DownloadButton'])[3]";
	public String Anatomicgroup="(//*[@Class='sorting-arrow'])[11]";
	public String Totalscan="(//*[@Class='sorting-arrow'])[13]";
	public String ImagingMode="(//*[@Class='sorting-arrow'])[12]";
	public String Systemtype="(//*[@Class='sorting-arrow'])[11]";
	public String anatomyperstrength="//*[text()='Anatomy Per Field Strength']";
	
	public String Adoptionperscantype="//*[@mr-eye-widget-type='Tab' and @mr-eye-widget-name='Adoption Per Scan Type']";
	public String Adoptionpersystemtype="//*[@mr-eye-widget-type='Tab' and @mr-eye-widget-name='Adoption Per System Type']";

	
	public String enabledexam="//*[text()='Smart Speed enabled Exams']";
	public String notenabledexam="//*[text()='Not enabled Exams']";
	
	
	
	
	
	
	
	
	
	
	
	

	

  public WebElement getElement(String xpath) {

	return driver.findElement(By.xpath(xpath));
}

}