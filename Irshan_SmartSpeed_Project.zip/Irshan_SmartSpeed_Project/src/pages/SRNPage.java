package pages;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.CTEye.action.ActionMethod;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Xpath.SRNPageXpath;
import utility.Base;
import utility.Loading;


public class SRNPage extends ActionMethod {
	
	
	static ExtentReports extentreport = new ExtentReports();

	static ExtentSparkReporter sparkreporter = new ExtentSparkReporter(
			"C:\\Users\\320198287\\eclipse-workspace\\Irshan_SmartSpeed_Project\\report.html");
	

	static Logger logger = Logger.getLogger("SRNPage");

	
	SRNPageXpath xpath;
	
	public static WebDriver driver;
	Loading l;

	@BeforeClass
	public void extentreport() throws IOException {
	
		extentreport.setSystemInfo("HostName", "MyHost");
		extentreport.setSystemInfo("ProjectName", "CTEye");
		extentreport.setSystemInfo("Tester", "Irshan");
		extentreport.setSystemInfo("OS", "Win10");
		extentreport.setSystemInfo("Browser", "Chrome");
		
	}

	@BeforeMethod

	public void setup() throws IOException, InterruptedException {

		Base b = new Base();
		logger.info("Webdriver initialization start");
		b.initializeBrowser("http://pww.mebef.healthcare.philips.com/Smart-Speed/SRN/48009");
		logger.info("Navigate to the end point URL");
		 
		driver = b.getdriver();
	   
		xpath = new SRNPageXpath(driver);
		l=new Loading();
		
		extentreport.attachReporter(sparkreporter);
		
		l.loading(driver);
		l.loading(driver);
		//l.loading(driver);

		
//		JavascriptExecutor js = (JavascriptExecutor) driver;
//        js.executeScript("window.scrollBy(0,850)", "");
//        Thread.sleep(240000);
//        
//       
//        js.executeScript("window.scrollBy(0,-950)", "");
		
		
		
        
        PropertyConfigurator.configure("Log4j.properties");

	}
	
	
	@Test(priority = 1)

	public void Scenario_9() throws InterruptedException {
	    JavascriptExecutor js = (JavascriptExecutor) driver;
		ExtentTest test1 = extentreport.createTest("Scenario_9");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of default KPIs");
		screenShot(driver, "scenario_9", "action_1");
		logger.info("Successfully Taken screenshot of default KPIs");
		test1.log(Status.PASS, "Take Screenshot");
		
		logger.info("Scrolling to Before First Use: Scan Sequence");
		js.executeScript("window.scrollBy(0,200)", "");
		logger.info("Scrolled to Before First Use: Scan Sequence");
		test1.log(Status.PASS, "Scroll to 'Before First Use: Scan Sequence'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of default KPIs");
		screenShot(driver, "scenario_9", "action_3");
		logger.info("Successfully Taken screenshot of default KPIs");
		test1.log(Status.PASS, "Take Screenshot");
		
		
		Thread.sleep(2000);
		logger.info("Downloading Before First Use: Scan Sequence as csv");
		click(driver, xpath.getElement(xpath.Beforescandownload));
		logger.info(" Downloaded Before First Use: Scan Sequence as csv");
		test1.log(Status.PASS, "Download as CSV in 'Before First Use: Scan Sequence'");
		
		Thread.sleep(2000);
		logger.info("Setting show entries to 50");
		selectBySendkeys("50", xpath.getElement(xpath.Beforeuseshowentries));
		logger.info("Successfully set");
		test1.log(Status.PASS, "Set 'Show Entries' to '50' in 'Before First Use: Scan Sequence'");
		
		Thread.sleep(2000);
		logger.info(" Sorting ExamCount in  ascendig order in Before First Use: Scan Sequence ");
		click(driver, xpath.getElement(xpath.Examcount));
		logger.info(" Successfully sorted ");
		test1.log(Status.PASS, "Sort on 'ExamCount' ascendingly in 'Before First Use: Scan Sequence'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of default KPIs");
		screenShot(driver, "scenario_9", "action_7");
		logger.info("Successfully Taken screenshot of default KPIs");
		test1.log(Status.PASS, "Take Screenshot");
		
		Thread.sleep(2000);
		logger.info("Drill down action start on row 2 and col 1");
		click(driver, xpath.getElement(xpath.Examcard2));
		logger.info("Drill down on row 2 and col 1");
		test1.log(Status.PASS, "Drill-down on 'Row:2'>'Col:1' in 'Before First Use: Scan Sequence'");
		

	    Thread.sleep(2000);
		logger.info("Searching HWS 1 in Before First Use: Scan Sequence");
		type(xpath.getElement(xpath.Beforeusesearch), "HWS 1");
		logger.info("Successfully search");
		test1.log(Status.PASS, "Enter 'Search' = 'HWS 1' in 'Before First Use: Scan Sequence'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of default KPIs");
		screenShot(driver, "scenario_9", "action_10");
		logger.info("Successfully Taken screenshot of default KPIs");
		test1.log(Status.PASS, "Take Screenshot");
		
		Thread.sleep(2000);
		logger.info("Downloading Before First Use: Scan Sequence as csv");
		click(driver, xpath.getElement(xpath.Beforescandownload));
		logger.info(" Downloaded Before First Use: Scan Sequence as csv");
		test1.log(Status.PASS, "Download as CSV in 'Before First Use: Scan Sequence'");
		
		
		
	}
	
	@Test(priority = 2)

	public void Scenario_10() throws InterruptedException {
	    JavascriptExecutor js = (JavascriptExecutor) driver;
		ExtentTest test2 = extentreport.createTest("Scenario_10");
		
		
		Thread.sleep(2000);
		logger.info("Scrolling to After First Use: Scan Sequence");
		js.executeScript("window.scrollBy(0,200)", "");
		logger.info("Scrolled to After First Use: Scan Sequence");
		test2.log(Status.PASS, "Scroll to 'After First Use: Scan Sequence'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of default KPIs");
		screenShot(driver, "scenario_10", "action_2");
		logger.info("Successfully Taken screenshot of default KPIs");
		test2.log(Status.PASS, "Take Screenshot");
		
		
		Thread.sleep(2000);
		logger.info("Downloading After First Use: Scan Sequence");
		click(driver, xpath.getElement(xpath.Afterscandownload));
		logger.info(" Downloaded After First Use: Scan Sequence");
		test2.log(Status.PASS, "Download as CSV in 'After First Use: Scan Sequence'");
		
		Thread.sleep(2000);
		logger.info("Setting show entries to All");
		selectBySendkeys("All", xpath.getElement(xpath.Afteruseshowentries));
		logger.info("Successfully set");
		test2.log(Status.PASS, "Set 'Show Entries' to 'All' in 'After First Use: Scan Sequence'");
		
		Thread.sleep(2000);
		logger.info(" Sorting SS Scan Count in  ascendig order in After First Use: Scan Sequence ");
		click(driver, xpath.getElement(xpath.sscount));
		logger.info(" Successfully sorted ");
		test2.log(Status.PASS, "Sort on 'SS Scan Count' ascendingly in 'After First Use: Scan Sequence'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of default KPIs");
		screenShot(driver, "scenario_10", "action_7");
		logger.info("Successfully Taken screenshot of default KPIs");
		test2.log(Status.PASS, "Take Screenshot");
		
		Thread.sleep(2000);
		logger.info("Drill down action start on row 2 and col 1");
		click(driver, xpath.getElement(xpath.Examcard14));
		logger.info("Drill down on row 4 and col 1");
		test2.log(Status.PASS, "Drill-down on 'Row:4'>'Col:1' in 'After First Use: Scan Sequence'");
		

	    Thread.sleep(2000);
		logger.info("Searching [Info] AI Knie rechts SMART Zeit in After First Use: Scan Sequence");
		type(xpath.getElement(xpath.Afterusesearch), "[Info] AI Knie rechts SMART Zeit");
		logger.info("Successfully search");
		test2.log(Status.PASS, "Enter 'Search' = '[Info] AI Knie rechts SMART Zeit' in 'After First Use: Scan Sequence'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of default KPIs");
		screenShot(driver, "scenario_10", "action_8");
		logger.info("Successfully Taken screenshot of default KPIs");
		test2.log(Status.PASS, "Take Screenshot");
		
		Thread.sleep(2000);
		logger.info("Downloading After First Use: Scan Sequence as csv");
		click(driver, xpath.getElement(xpath.Afterscandownload));
		logger.info(" Downloaded Before First Use: Scan Sequence as csv");
		test2.log(Status.PASS, "Download as CSV in 'After First Use: Scan Sequence'");
		
		
		
	}
	
	@Test(priority = 3)

	public void Scenario_11() throws InterruptedException {
	    JavascriptExecutor js = (JavascriptExecutor) driver;
		ExtentTest test3 = extentreport.createTest("Scenario_11");
		
		Thread.sleep(2000);
		logger.info("Scrolling to Before First Use: Activity Durations");
		js.executeScript("window.scrollBy(0,700)", "");
		logger.info("Scrolled to Before First Use: Activity Durations");
		test3.log(Status.PASS, "Scroll to 'Before First Use: Activity Durations'");
		
		Thread.sleep(2000);
		logger.info("Downloading Before First Use: Activity Durations as csv");
		click(driver, xpath.getElement(xpath.Beforeactivitydownload));
		logger.info(" Downloaded Before First Use: Activity Durations as csv");
		test3.log(Status.PASS, "Download as CSV in 'Before First Use: Activity Durations'");
		
		Thread.sleep(2000);
		logger.info("Downloading Before First Use: Activity Durations as csv");
		click(driver, xpath.getElement(xpath.Afteractivitydownload));
		logger.info(" Downloaded Before First Use: Activity Durations as csv");
		test3.log(Status.PASS, "Download as CSV in 'After First Use: Activity Durations'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of Before First Use: Activity Durations");
		screenShot(driver, "scenario_11", "action_4");
		logger.info("Successfully Taken screenshot of Before First Use: Activity Durations");
		test3.log(Status.PASS, "Take Screenshot");
		
		Thread.sleep(2000);
		logger.info("Scrolling to Anatomy Mix % Share of anatomy in exams performed");
		js.executeScript("window.scrollBy(0,550)", "");
		logger.info("Scrolling to Anatomy Mix % Share of anatomy in exams performed");
		test3.log(Status.PASS, "Scroll to 'Anatomy Mix % Share of anatomy in exams performed'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of Anatomy Mix % Share of anatomy in exams performed");
		screenShot(driver, "scenario_11", "action_6");
		logger.info("Successfully Taken screenshot of Anatomy Mix % Share of anatomy in exams performed");
		test3.log(Status.PASS, "Take Screenshot");
		
		Thread.sleep(2000);
		logger.info("Downloading Anatomy Mix % Share of anatomy in exams performed as csv");
		click(driver, xpath.getElement(xpath.Anatomymixdownload));
		logger.info(" Downloaded Anatomy Mix % Share of anatomy in exams performed as csv");
		test3.log(Status.PASS, "Download as CSV in 'Anatomy Mix % Share of anatomy in exams performed'");
		
		Thread.sleep(2000);
		logger.info("Mouse over on Abdomen");
		mouseHoverByJavaScript(driver, xpath.getElement(xpath.Abdomen));
		logger.info("Successfully Mouse over on Abdomen");
		test3.log(Status.PASS, "Hover over 'ABDOMEN' in 'Anatomy Mix % Share of anatomy in exams performed'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of Anatomy Mix % Share of anatomy in exams performed");
		screenShot(driver, "scenario_11", "action_9");
		logger.info("Successfully Taken screenshot of Anatomy Mix % Share of anatomy in exams performed");
		test3.log(Status.PASS, "Take Screenshot");
		
		Thread.sleep(2000);
		logger.info("Switching to  Anatomic Group");
		click(driver, xpath.getElement(xpath.Anatomicbutton));
		logger.info("Successfully switch to Anatomic Group");
		test3.log(Status.PASS, "Switch to 'Anatomic Group' in 'Anatomy Mix % Share of anatomy in exams performed'");
		
		Thread.sleep(2000);
		logger.info("Mouse over on SPINE");
		mouseHoverByJavaScript(driver, xpath.getElement(xpath.Spine));
		logger.info("Successfully Mouse over on SPINE");
		test3.log(Status.PASS, "Hover over 'SPINE' in 'Anatomy Mix % Share of anatomy in exams performed'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of default KPIs");
		screenShot(driver, "scenario_11", "action_12");
		logger.info("Successfully Taken screenshot of default KPIs");
		test3.log(Status.PASS, "Take Screenshot");
		
		Thread.sleep(2000);
		logger.info("Downloading Anatomy Mix % Share of anatomy in exams performed as csv");
		click(driver, xpath.getElement(xpath.Anatomymixdownload));
		logger.info(" Downloaded Anatomy Mix % Share of anatomy in exams performed as csv");
		test3.log(Status.PASS, "Download as CSV in 'Anatomy Mix % Share of anatomy in exams performed'");
		
	}
	
	
	@Test(priority = 4)

	public void Scenario_12() throws InterruptedException {
	    JavascriptExecutor js = (JavascriptExecutor) driver;
		ExtentTest test4 = extentreport.createTest("Scenario_12");
		
		Thread.sleep(2000);
		logger.info("Scrolling to Adoption Per Anatomy");
		js.executeScript("window.scrollBy(0,1200)", "");
		logger.info("Scrolling to Adoption Per Anatomy");
		test4.log(Status.PASS, "Scroll to 'Adoption Per Anatomy'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of Adoption Trend");
		screenShot(driver, "scenario_12", "action_2");
		logger.info("Successfully Taken screenshot of Adoption Trend");
		test4.log(Status.PASS, "Take Screenshot");
		
	    Thread.sleep(2000);
		logger.info("Downloading After First Use: Activity Durations as csv");
		click(driver, xpath.getElement(xpath.Adoptionanatomydownload));
		logger.info(" Downloaded After First Use: Activity Durations as csv");
		test4.log(Status.PASS, "Download as CSV in 'After First Use: Activity Durations'");
		
		Thread.sleep(2000);
		logger.info("Switching to  Anatomic Region");
		click(driver, xpath.getElement(xpath.Adoptionperanatomybutton));
		logger.info("Successfully switch to Anatomic Region");
		test4.log(Status.PASS, "Switch to 'Anatomic Region' in 'After First Use: Activity Durations'");
		
		Thread.sleep(2000);
		logger.info("Scrolling to Adoption Trend");
		js.executeScript("window.scrollBy(0,750)", "");
		logger.info("Scrolled to Adoption Trend");
		test4.log(Status.PASS, "Scroll to 'Adoption Trend Per Calendar Week'");
		
		Thread.sleep(2000);
		logger.info("Downloading Adoption Trend Per Calendar Week as csv");
		click(driver, xpath.getElement(xpath.Adoptiondownload));
		logger.info(" Downloaded Anatomy Mix % Share of anatomy in exams performed as csv");
		test4.log(Status.PASS, "Download as CSV in 'Adoption Trend Per Calendar Week'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of Adoption Trend");
		screenShot(driver, "scenario_12", "action_7");
		logger.info("Successfully Taken screenshot of Adoption Trend");
		test4.log(Status.PASS, "Take Screenshot");
		
		Thread.sleep(3000);
		logger.info("Switching to  Adoption w.r.t Full Pack");
		click(driver, xpath.getElement(xpath.Adoptionfullpackbutton));
		logger.info("Successfully switch to Adoption w.r.t Full Pack");
		test4.log(Status.PASS, "Switch to 'Adoption w.r.t Full Pack' in 'Adoption Trend Per Calendar Week'");
		
		Thread.sleep(2000);
		logger.info("Downloading Adoption Trend Per Calendar Week as csv");
		click(driver, xpath.getElement(xpath.Adoptiondownload));
		logger.info(" Downloaded Anatomy Mix % Share of anatomy in exams performed as csv");
		test4.log(Status.PASS, "Download as CSV in 'Adoption Trend Per Calendar Week'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of Adoption Trend");
		screenShot(driver, "scenario_12", "action_10");
		logger.info("Successfully Taken screenshot of Adoption Trend");
		test4.log(Status.PASS, "Take Screenshot");
		
		
		}
	
	
	
	
	 @AfterMethod()

		public void teardown() {

			extentreport.flush();
			
			//driver.quit();

		}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
