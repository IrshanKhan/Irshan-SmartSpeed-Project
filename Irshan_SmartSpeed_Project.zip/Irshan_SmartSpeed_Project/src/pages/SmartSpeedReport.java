package pages;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.CTEye.action.ActionMethod;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import Xpath.SmartSpeedReportXpath;
import utility.Base;
import utility.Loading;

public class SmartSpeedReport extends ActionMethod {
	
	static ExtentReports extentreport = new ExtentReports();

	static ExtentSparkReporter sparkreporter = new ExtentSparkReporter(
			"C:\\Users\\320198287\\eclipse-workspace\\Irshan_SmartSpeed_Project\\report.html");
	

	static Logger logger = Logger.getLogger("SmartSpeedReport");

	Loading l;
	SmartSpeedReportXpath xpath;
	
	public static WebDriver driver;

	@BeforeClass
	public void extentreport() throws IOException {
	
		extentreport.setSystemInfo("HostName", "MyHost");
		extentreport.setSystemInfo("ProjectName", "CTEye");
		extentreport.setSystemInfo("Tester", "Irshan");
		extentreport.setSystemInfo("OS", "Win10");
		extentreport.setSystemInfo("Browser", "Chrome");
		
	}

	@BeforeMethod

	public void setup() throws IOException, InterruptedException {

		Base b = new Base();
		logger.info("Webdriver initialization start");
		b.initializeBrowser("http://pww.mebef.healthcare.philips.com/Smart-Speed/report");  //http://ingbtcpic5vw242:5677/CT-Eye/bolusView/(previous test link)
		logger.info("Navigate to the end point URL");
		 
		driver = b.getdriver();
	   
		xpath = new SmartSpeedReportXpath(driver);
		l=new Loading();
		extentreport.attachReporter(sparkreporter);
		l.loading(driver);
		Thread.sleep(6000);
        
        PropertyConfigurator.configure("Log4j.properties");

	}
	
	
	@Test(priority = 1)

	public void Scenario_13() throws InterruptedException {
	    JavascriptExecutor js = (JavascriptExecutor) driver;
		ExtentTest test1 = extentreport.createTest("Scenario_13");
		
		Thread.sleep(4000);
		logger.info("Taking screenshot of default report page");
		screenShot(driver, "scenario_13", "action_1");
		logger.info("Successfully Taken screenshot of default report page");
		test1.log(Status.PASS, "Take Screenshot");
		
		Thread.sleep(2000);
		logger.info("Clicking on SRN in Benifit Filter Map ");
		click(driver, xpath.getElement(xpath.SRN));
		logger.info(" Successfully clicked on SRN in Benifit Filter Map ");
		test1.log(Status.PASS, "Click on 'SRN' in 'Benifit Filter Map'");
		
		Thread.sleep(2000);
		logger.info("Searching 47037 in Benifit Filter Map");
		type(xpath.getElement(xpath.SRNsearch), "47037, cherokee health park");
		logger.info("Successfully search");
		test1.log(Status.PASS, "Enter 'Search' = '47037' in 'Benifit Filter Map'");
		
		Thread.sleep(2000);
		logger.info("Clicking on Get Details in Benifit Filter Map ");
		click(driver, xpath.getElement(xpath.SRNClick));
		logger.info(" Successfully clicked on Get Details in Benifit Filter Map ");
		test1.log(Status.PASS, "Click on 'SRN' in 'Benifit Filter Map'");
		
		Thread.sleep(2000);
		logger.info("Clicking on Get Details in Benifit Filter Map ");
		click(driver, xpath.getElement(xpath.GetDetails));
		logger.info(" Successfully clicked on Get Details in Benifit Filter Map ");
		test1.log(Status.PASS, "Click on 'GetDetails' in 'Benifit Filter Map'");
		
		Thread.sleep(180000);
		logger.info("Scrolling to Anatomy");
		js.executeScript("window.scrollBy(0,300)", "");
		logger.info("Scrolled to Anatomy");
		test1.log(Status.PASS, "Scroll to 'Anatomy'");
		
		Thread.sleep(4000);
		logger.info("Taking screenshot of default report page");
		screenShot(driver, "scenario_13", "action_7");
		logger.info("Successfully Taken screenshot of default report page");
		test1.log(Status.PASS, "Take Screenshot");
		
		Thread.sleep(2000);
		logger.info("Clicking on Brain checkbox ");
		click(driver, xpath.getElement(xpath.UncheckBrain));
		logger.info(" Successfully clicked on Brain in BenifitMap ");
		test1.log(Status.PASS, "Click on 'Brain' in 'BenifitMap'");
		
		Thread.sleep(2000);
		logger.info("Clicking on Knee checkbox ");
		click(driver, xpath.getElement(xpath.CheckKnee));
		logger.info(" Successfully clicked on Knee in BenifitMap ");
		test1.log(Status.PASS, "Click on 'Knee' in 'BenifitMap'");
		
		Thread.sleep(2000);
		logger.info("Scrolling to end of the page");
		js.executeScript("window.scrollBy(0,400)", "");
		logger.info("Scrolled to end of the page");
		test1.log(Status.PASS, "Scroll to end of the page");
		
		
		Thread.sleep(2000);
		logger.info("Clicking on Aggressive checkbox ");
		click(driver, xpath.getElement(xpath.Aggressive));
		logger.info(" Successfully clicked on Aggressive in BenifitMap ");
		test1.log(Status.PASS, "Click on 'Aggressive' in 'BenifitMap'");
		
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of default report page");
		screenShot(driver, "scenario_13", "action_12");
		logger.info("Successfully Taken screenshot of default report page");
		test1.log(Status.PASS, "Take Screenshot");
		
		Thread.sleep(2000);
		logger.info("Clicking on actual checkbox ");
		click(driver, xpath.getElement(xpath.Actual));
		logger.info(" Successfully clicked on Aggressive in BenifitMap ");
		test1.log(Status.PASS, "Click on 'Actual' in 'BenifitMap'");
		
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of default report page");
		screenShot(driver, "scenario_13", "action_14");
		logger.info("Successfully Taken screenshot of default report page");
		test1.log(Status.PASS, "Take Screenshot");
		
		
		
		
		}
	
	@Test(priority = 2)

	public void Scenario_14() throws InterruptedException {
	    JavascriptExecutor js = (JavascriptExecutor) driver;
		ExtentTest test2 = extentreport.createTest("Scenario_14");
		
		Thread.sleep(2000);
		logger.info("Clicking on SRN in Benifit Filter Map ");
		click(driver, xpath.getElement(xpath.SRN));
		logger.info(" Successfully clicked on SRN in Benifit Filter Map ");
		test2.log(Status.PASS, "Click on 'SRN' in 'Benifit Filter Map'");
		
		Thread.sleep(2000);
		logger.info("Searching 47037 in Benifit Filter Map");
		type(xpath.getElement(xpath.SRNsearch), "47037, cherokee health park");
		logger.info("Successfully search");
		test2.log(Status.PASS, "Enter 'Search' = '47037' in 'Benifit Filter Map'");
		
		Thread.sleep(2000);
		logger.info("Clicking on Get Details in Benifit Filter Map ");
		click(driver, xpath.getElement(xpath.SRNClick));
		logger.info(" Successfully clicked on Get Details in Benifit Filter Map ");
		test2.log(Status.PASS, "Click on 'SRN' in 'Benifit Filter Map'");
		
		Thread.sleep(2000);
		logger.info("Clicking on Get Details in Benifit Filter Map ");
		click(driver, xpath.getElement(xpath.GetDetails));
		logger.info(" Successfully clicked on Get Details in Benifit Filter Map ");
		test2.log(Status.PASS, "Click on 'GetDetails' in 'Benifit Filter Map'");
		
		Thread.sleep(180000);
		Thread.sleep(2000);
		logger.info("Taking screenshot of default report page");
		screenShot(driver, "scenario_14", "action_5");
		logger.info("Successfully Taken screenshot of default report page");
		test2.log(Status.PASS, "Take Screenshot");
		
		
		Thread.sleep(2000);
		logger.info("Clicking on SRN in Benifit Filter Map ");
		click(driver, xpath.getElement(xpath.SRN));
		logger.info(" Successfully clicked on SRN in Benifit Filter Map ");
		test2.log(Status.PASS, "Click on 'SRN' in 'Benifit Filter Map'");
		
		Thread.sleep(2000);
		logger.info("Searching 48009 in Benifit Filter Map");
		type(xpath.getElement(xpath.SRNsearch), "48009, mrt-praxis potsdam");
		logger.info("Successfully search");
		test2.log(Status.PASS, "Enter 'Search' = '48009, mrt-praxis potsdam'");
		
		Thread.sleep(2000);
		logger.info("Clicking on SRN in Benifit Filter Map ");
		click(driver, xpath.getElement(xpath.SRNClick1));
		logger.info(" Successfully clicked on SRN in Benifit Filter Map ");
		test2.log(Status.PASS, "Click on 'SRN' in 'Benifit Filter Map'");
		
		Thread.sleep(2000);
		logger.info("Clicking on Get Details in Benifit Filter Map ");
		click(driver, xpath.getElement(xpath.GetDetails));
		logger.info(" Successfully clicked on Get Details in Benifit Filter Map ");
		test2.log(Status.PASS, "Click on 'GetDetails' in 'Benifit Filter Map'");
		
		Thread.sleep(180000);
		logger.info("Scrolling to end of the page");
		js.executeScript("window.scrollBy(0,500)", "");
		logger.info("Scrolled to end of the page");
		test2.log(Status.PASS, "Scroll to 'Anatomy'");
		
		Thread.sleep(4000);
		logger.info("Taking screenshot of default report page");
		screenShot(driver, "scenario_14", "action_11");
		logger.info("Successfully Taken screenshot of default report page");
		test2.log(Status.PASS, "Take Screenshot");
		
		Thread.sleep(2000);
		logger.info("Clicking on Knee checkbox ");
		click(driver, xpath.getElement(xpath.CheckKnee));
		logger.info(" Successfully clicked on Knee in BenifitMap ");
		test2.log(Status.PASS, "Click on 'Knee' in 'BenifitMap'");
		
		Thread.sleep(2000);
		logger.info("Clicking on Aggressive checkbox ");
		click(driver, xpath.getElement(xpath.Aggressive));
		logger.info(" Successfully clicked on Aggressive in BenifitMap ");
		test2.log(Status.PASS, "Click on 'Aggressive' in 'BenifitMap'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of default report page");
		screenShot(driver, "scenario_14", "action_14");
		logger.info("Successfully Taken screenshot of default report page");
		test2.log(Status.PASS, "Take Screenshot");
		
		Thread.sleep(2000);
		logger.info("Clicking on Actual checkbox ");
		click(driver, xpath.getElement(xpath.Actual));
		logger.info(" Successfully clicked on Actual in BenifitMap ");
		test2.log(Status.PASS, "Click on 'Actual' in 'BenifitMap'");
		
		Thread.sleep(2000);
		logger.info("Taking screenshot of default report page");
		screenShot(driver, "scenario_14", "action_16");
		logger.info("Successfully Taken screenshot of default report page");
		test2.log(Status.PASS, "Take Screenshot");
		
		
		
		
	}
	
	 @AfterMethod()

		public void teardown() {

			extentreport.flush();
			
			//driver.quit();

		}

}
