package utility;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class Loading {
	
	public static WebDriver driver;
	
	public  void loading (WebDriver driver) throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 
		 js.executeScript("window.scrollBy(0,300)", "");
		 Thread.sleep(5000);
		 js.executeScript("window.scrollBy(0,300)", "");
		 Thread.sleep(6000);
		 js.executeScript("window.scrollBy(0,300)", "");
		 Thread.sleep(7000);
		 js.executeScript("window.scrollBy(0,300)", "");
		 Thread.sleep(8000);
		 js.executeScript("window.scrollBy(0,300)", "");
		 Thread.sleep(8000);
		 js.executeScript("window.scrollBy(0,-300)", "");
		 Thread.sleep(7000);
		 js.executeScript("window.scrollBy(0,-300)", "");
		 Thread.sleep(6000);
		 js.executeScript("window.scrollBy(0,-300)", "");
		 Thread.sleep(5000);
		 js.executeScript("window.scrollBy(0,-300)", "");
		 Thread.sleep(4000);
		 js.executeScript("window.scrollBy(0,-300)", "");
		
		
	}
	
public  void loading1 (WebDriver driver) throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,-300)", "");
		 Thread.sleep(2000);
		 js.executeScript("window.scrollBy(0,-300)", "");
		 Thread.sleep(2000);
		 js.executeScript("window.scrollBy(0,-300)", "");
		 Thread.sleep(2000);
		 js.executeScript("window.scrollBy(0,-300)", "");
		 Thread.sleep(3000);
		 js.executeScript("window.scrollBy(0,-300)", "");
		 Thread.sleep(3000);
		 js.executeScript("window.scrollBy(0,300)", "");
		 Thread.sleep(2000);
		 js.executeScript("window.scrollBy(0,300)", "");
		 Thread.sleep(2000);
		 js.executeScript("window.scrollBy(0,300)", "");
		 Thread.sleep(2000);
		 js.executeScript("window.scrollBy(0,300)", "");
		 Thread.sleep(2000);
		 js.executeScript("window.scrollBy(0,300)", "");
		 
		 
		
		
	}
	
	
	
}
