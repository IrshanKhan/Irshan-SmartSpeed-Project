package utility;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Attachscreenshot {

	
	public static WebDriver driver;
	public static String capturescreenShot1() {
		//String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
		String base64Code=takesScreenshot.getScreenshotAs(OutputType.BASE64);
		return base64Code;
	}
	
	
	
}



